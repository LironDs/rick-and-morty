// import Character from "./Character";

export default interface Episode {
  id?: number;
  name: string;
  air_date: string;
  characters: [];
  characterData: [];
}
